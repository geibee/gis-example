SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: layers; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app.layers (id, project_id, name, schema_name, table_name, geometry_column, geometry_type, source_srid, display_srid, feature_id_column, bbox_4326, row_count, is_result, tile_source_id, created_at) FROM stdin;
54240d3d-0b3d-4d66-9f6d-07af52c6df5a	00000000-0000-0000-0000-000000000000	地価公示 2023 東京	gis_data	layer_3b9b0c411f0b_l01_23_13	geom	MULTIPOINT	4326	3857	fid	[139.13642111100012, 27.094904722000017, 142.2033550000001, 35.82835888900007]	2602	f	layer_3b9b0c411f0b_l01_23_13	2026-06-17 00:52:34.148994+00
5e7374f2-af82-481d-bc75-3e4ad51bfdaa	00000000-0000-0000-0000-000000000000	小地域（町丁・字等）2020 東京	gis_data	layer_cc48bf4ca1d9_estat_tokyo_smallarea	geom	MULTIPOLYGON	4612	3857	fid	[136.06983562525437, 20.42500902563164, 153.98280441789507, 35.89836743406822]	6021	f	layer_cc48bf4ca1d9_estat_tokyo_smallarea	2026-06-17 01:17:36.569933+00
1f7f2ea0-020a-4f5d-8443-fc401c086792	00000000-0000-0000-0000-000000000000	坪単価200万以上の小地域	gis_data	result_3a8bac31ee0e4f71929097bc	geom	MULTIPOLYGON	3857	3857	fid	[139.33505517925042, 35.54034791031007, 139.905350748514, 35.78373422546525]	813	t	result_3a8bac31ee0e4f71929097bc	2026-06-17 01:22:34.603596+00
\.

--
-- Data for Name: layer_attributes; Type: TABLE DATA; Schema: app; Owner: -
--

COPY app.layer_attributes (id, layer_id, name, data_type, ordinal_position, is_geometry) FROM stdin;
1c004fb1-7977-4fb6-9568-7b1ae39a3022	1f7f2ea0-020a-4f5d-8443-fc401c086792	fid	integer	1	f
f51970c2-9e33-4136-9a4b-3392a3c3b3be	1f7f2ea0-020a-4f5d-8443-fc401c086792	geom	geometry	2	t
cd16c959-143c-4ba7-86bd-83a16e61b575	1f7f2ea0-020a-4f5d-8443-fc401c086792	key_code	character varying	3	f
8bc8ae90-0f37-4d7e-ba40-7d2496445c8e	1f7f2ea0-020a-4f5d-8443-fc401c086792	pref	character varying	4	f
79cfc934-d2bd-4777-b036-d6ef1104effe	1f7f2ea0-020a-4f5d-8443-fc401c086792	city	character varying	5	f
e00f0f4a-ecee-41b0-bc2d-8e43c0498a4e	1f7f2ea0-020a-4f5d-8443-fc401c086792	s_area	character varying	6	f
f2ce301d-ba11-4d44-a91b-10a4b652cf72	1f7f2ea0-020a-4f5d-8443-fc401c086792	pref_name	character varying	7	f
61f608cf-9c4d-4b32-8118-2282dde77cbc	1f7f2ea0-020a-4f5d-8443-fc401c086792	city_name	character varying	8	f
dbfcbade-160b-41cc-b59d-9bb19ab818f8	1f7f2ea0-020a-4f5d-8443-fc401c086792	s_name	character varying	9	f
336de10d-0184-4604-9a8e-79ef37da6b5b	1f7f2ea0-020a-4f5d-8443-fc401c086792	kigo_e	character varying	10	f
25218f7d-45e0-480d-b8aa-c35d9953a1bd	1f7f2ea0-020a-4f5d-8443-fc401c086792	hcode	integer	11	f
ed1f231d-d029-4c89-bea5-03cf4029d34e	1f7f2ea0-020a-4f5d-8443-fc401c086792	area	double precision	12	f
d2eca54f-99b0-4724-9c3e-a4038bdd1698	1f7f2ea0-020a-4f5d-8443-fc401c086792	perimeter	double precision	13	f
0cdd8c4b-93c2-4aa6-bd7c-c77344076715	1f7f2ea0-020a-4f5d-8443-fc401c086792	r2kaxx	integer	14	f
465db5e5-33ac-445c-b3e4-73a389589697	1f7f2ea0-020a-4f5d-8443-fc401c086792	r2kaxx_id	integer	15	f
5eb24ad8-b117-42fb-a274-d4ff0177f83e	1f7f2ea0-020a-4f5d-8443-fc401c086792	kihon1	character varying	16	f
2a8a953c-700e-42e2-bd89-bd3140968cab	1f7f2ea0-020a-4f5d-8443-fc401c086792	dummy1	character varying	17	f
68370d0f-cbd1-4f96-b276-418586290b3e	1f7f2ea0-020a-4f5d-8443-fc401c086792	kihon2	character varying	18	f
d557e68f-25f9-4041-a2cd-05eda8f462eb	1f7f2ea0-020a-4f5d-8443-fc401c086792	keycode1	character varying	19	f
a8ed44bd-249e-4829-b3ca-5074bbabd1e3	1f7f2ea0-020a-4f5d-8443-fc401c086792	keycode2	character varying	20	f
80847cd7-6af5-49e6-88fe-b784d80df2f1	1f7f2ea0-020a-4f5d-8443-fc401c086792	area_max_f	character varying	21	f
db8473b2-9878-4874-b3a1-d5671c4dd08e	1f7f2ea0-020a-4f5d-8443-fc401c086792	kigo_d	character varying	22	f
27c0c3c1-92fd-4be1-a48a-fb67698a8ede	1f7f2ea0-020a-4f5d-8443-fc401c086792	n_ken	character varying	23	f
852e30e3-35bd-4549-82f7-d2ada05fa86a	1f7f2ea0-020a-4f5d-8443-fc401c086792	n_city	character varying	24	f
488b4f9c-aaa8-48a0-ab36-cdaedea7d7ee	1f7f2ea0-020a-4f5d-8443-fc401c086792	kigo_i	character varying	25	f
66104113-2367-4a59-8dac-eab4bde47aff	1f7f2ea0-020a-4f5d-8443-fc401c086792	kbsum	integer	26	f
5a1ae34c-1da6-4575-b9ab-d8e2f00828ea	1f7f2ea0-020a-4f5d-8443-fc401c086792	jinko	bigint	27	f
bb1d1e1a-4d0d-4143-9b83-bcc0a12df0fe	1f7f2ea0-020a-4f5d-8443-fc401c086792	setai	bigint	28	f
99cf214e-3fef-441c-8151-806240908aaa	1f7f2ea0-020a-4f5d-8443-fc401c086792	x_code	double precision	29	f
c0bf3ea7-6466-4efb-908a-8b8ff8d69069	1f7f2ea0-020a-4f5d-8443-fc401c086792	y_code	double precision	30	f
2ce73561-5941-462f-a06d-3720219b6821	1f7f2ea0-020a-4f5d-8443-fc401c086792	kcode1	character varying	31	f
37fbb435-f588-4419-ab4a-b08528fb1a98	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	fid	integer	1	f
0a48c7cf-130f-4d61-81a1-d22c182e471b	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	geom	geometry	2	t
b0d326ce-9089-4ecb-801d-e155f50a9c7d	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_001	character varying	3	f
2978eb6b-bc84-452d-8bc2-1c294451d586	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_002	character varying	4	f
28afa24b-ef12-4751-b7d9-5d96b7f91e5d	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_003	character varying	5	f
c8daefc5-3e6b-45cc-b254-2a63f18e39ce	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_004	character varying	6	f
d92a87f4-d4d6-4e7d-b625-afb98a28fc62	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_005	character varying	7	f
d21e8abf-d844-493b-8ec8-f3f15a85f42e	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_006	integer	8	f
f9ef690c-1123-4a58-889e-db07299db097	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_007	double precision	9	f
fc886cc4-0fb2-4499-aae8-dfac35f0a307	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_008	integer	10	f
9a0ad833-7839-40ba-a4f5-4939f0c925ae	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_009	character varying	11	f
401d1eff-1ba6-4101-9453-58bcb03f9c2c	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_010	character varying	12	f
94d44130-3d91-4c7a-ada5-6f4acfe7b988	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_011	character varying	13	f
c4700410-a321-4e9d-84c3-b5c454de3ed2	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_012	character varying	14	f
c72462ac-ea5c-4bc4-9ce7-c594138f0672	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_013	character varying	15	f
1d766913-94ee-45d9-9474-8543050d07a7	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_014	character varying	16	f
bfbc6eac-9bdf-462a-ad41-9d72b23a60a9	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_015	character varying	17	f
1242ee97-abde-46b7-8600-b25ac2f4786e	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_016	character varying	18	f
78ac53cc-a00a-4a18-b575-62eefd89163b	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_017	character varying	19	f
ec7efd0d-21bc-4dd5-ba08-90fd627d5328	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_018	character varying	20	f
6222cfa2-72a5-450b-ad30-a21704e97c8d	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_019	character varying	21	f
6ddd6670-a8d0-485d-b8da-0d2cb09d6336	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_020	character varying	22	f
0e3e0734-8a54-4a85-b9bf-8a2bdbeb56c5	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_021	character varying	23	f
394ce699-3387-4056-be85-a0708987c586	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_022	character varying	24	f
10645fdd-ac11-47c3-ad0b-a3ae9c620706	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_023	character varying	25	f
c51a51a8-f58d-48eb-9ce0-be2c8f80ac22	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_024	character varying	26	f
fb175d86-249f-4dd5-b508-8e7e2dd4f371	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_025	character varying	27	f
d7edcc0b-0018-407c-b487-7fda1100e983	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_026	integer	28	f
4e37f81c-cde0-4146-9d38-657217e797a4	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_027	character varying	29	f
9ac9db21-2a50-4ac4-b283-da3513f8efa1	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_028	character varying	30	f
c2566bde-1b77-4454-860e-ad8b57237b02	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_029	character varying	31	f
f9df06fd-b120-4f1d-8909-65b5a266a6e5	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_030	character varying	32	f
10fde5a9-88b5-4d34-b8aa-ffde27009837	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_031	character varying	33	f
e8bb97cc-cd69-4e84-acf0-f034e51846ae	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_032	character varying	34	f
b8210ed7-5046-4680-af20-8372b9a30a29	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_033	character varying	35	f
a5c7cccb-4ecb-4da8-91b5-89c8bf3d3c71	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_034	character varying	36	f
9df1dbbc-b96c-4a16-93ee-5605df2c81c9	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_035	double precision	37	f
12a78574-9fa1-495b-ad02-e33f9123cd5a	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_036	double precision	38	f
0d28a55d-901b-47f4-9366-5d8f066dc63b	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_037	integer	39	f
9e1d1dcc-7f82-4813-829f-e227ee1ce5f4	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_038	integer	40	f
7605f05b-b28f-4df9-a86b-052606a2f961	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_039	character varying	41	f
99a20cf1-ea8c-4134-8939-2d45a3288324	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_040	character varying	42	f
4a2a82c2-b968-4c02-9273-35bd66ef13ba	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_041	double precision	43	f
767e6526-29c8-4fbb-990b-6c0d9533fdb2	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_042	character varying	44	f
6f0d6e5c-99b4-4dcf-96b3-dfef29fc5726	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_043	character varying	45	f
f63283ab-2d70-4130-bc48-76d11f272507	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_044	character varying	46	f
b4f2731e-2aa5-4974-83e7-8f37f256653e	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_045	character varying	47	f
28c6e738-b880-4940-a4fb-fc1e41579218	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_046	character varying	48	f
4ca9584e-b1dd-4275-a9c5-fc1db1dcc5c5	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_047	character varying	49	f
4121c492-658d-41b2-aba4-cdaa0e215ca1	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_048	character varying	50	f
f0c32987-c0fd-467b-bf20-574c8d4b3788	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_049	integer	51	f
ee4da980-4aba-4f63-9a6e-97578c832b07	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_050	character varying	52	f
5e2713df-4b43-4701-b4de-c21392ea998c	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_051	character varying	53	f
4cb70dcc-415d-4471-a9aa-36f349895794	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_052	character varying	54	f
749c4dd5-6651-4421-afb3-10309b1bd30c	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_053	character varying	55	f
5e7dcc76-b336-4462-9d46-4b587954e040	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_054	character varying	56	f
ead4b068-e059-49af-bb8c-202e867956e9	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_055	character varying	57	f
8b2f377f-60a3-4666-93c2-4947470d26f1	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_056	integer	58	f
38daff92-6b00-4048-9bb2-c9acec439873	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_057	integer	59	f
3c754ff7-f9b4-4cf7-9b8f-5e524546678a	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_058	character varying	60	f
7033ee1d-a242-4fa6-8e55-3f5d8713380a	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_059	character varying	61	f
7e66b510-9374-48e2-9fdc-91f3da8ee999	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_060	character varying	62	f
34f7d916-0e8e-43b5-b8cb-b3df244be4a4	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_061	integer	63	f
a692f7ae-826a-4055-ab13-93400cc2d3aa	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_062	integer	64	f
d72c20c8-0d13-41c4-983e-188d8f0ee670	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_063	integer	65	f
0c4790dd-f28d-463f-9e9b-d9d7bde6801c	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_064	integer	66	f
53afc96b-8ced-403b-a840-866d512db986	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_065	integer	67	f
216763aa-bb86-40a7-bcc4-4b65d8194ce4	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_066	integer	68	f
fe6a950c-adc4-4f6b-9674-cd1dc6924a2c	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_067	integer	69	f
f5cd3cf9-e810-495a-8515-4e60306f7f53	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_068	integer	70	f
dd7b4735-2ee5-49e3-9e78-0790170d4005	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_069	integer	71	f
16cedaa4-075b-4cb6-b4c7-2782c72fa671	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_070	integer	72	f
11fe0830-790d-4ce5-a322-e9bb5c899616	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_071	integer	73	f
21b8b89a-9de0-4dd5-b9ed-011616bf9d90	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_072	integer	74	f
4cc16442-270c-4c0f-a5e6-3f7881417f82	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_073	integer	75	f
9d861329-15b8-4970-8a0b-fab929a27d03	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_074	integer	76	f
1ea6c1df-3087-427b-8f69-f6c118ef4ccc	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_075	integer	77	f
477eea04-0c61-4c8f-8505-1558fb2407e1	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_076	integer	78	f
e63f2ccd-3b7c-48a2-becc-789813e17648	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_077	integer	79	f
4a5325e9-9b00-4c46-b2ce-545eeee65d15	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_078	integer	80	f
e508efaa-52d9-4e4e-bc0c-af5bbdedefb6	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_079	integer	81	f
0f67acb1-b76a-4177-88a1-dd5fd87e855e	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_080	integer	82	f
1a13be03-a317-42f9-bee5-395ed62cf3ba	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_081	integer	83	f
14895648-377f-402b-9f84-9d079c9dc285	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_082	integer	84	f
533f18ea-4493-471c-8f0a-d5cf845d5cad	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_083	integer	85	f
93d7a6c9-e404-46f8-bff5-5e40b012c7ab	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_084	integer	86	f
21ad147e-3911-45fc-9f48-750c792860dd	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_085	integer	87	f
d539d899-6493-463e-bc2b-0553cb090475	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_086	integer	88	f
6ee9e2c5-e850-4767-a689-a8805b155125	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_087	integer	89	f
ab7c8d27-0ed6-4c1d-add3-fa8bc2b4766e	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_088	integer	90	f
73365ecd-76ce-4176-944f-789f59674e34	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_089	integer	91	f
61ba6132-1f30-4c6d-931e-0c3f325914a5	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_090	integer	92	f
0264297d-eb05-4e73-ad1c-dfe6b9adb748	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_091	integer	93	f
c0ff7ebe-04b4-4522-affa-121c2fc37cb6	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_092	integer	94	f
48f16f31-f475-475c-9875-e3f3dd7d3e30	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_093	integer	95	f
abccde44-9844-4b08-b959-c63bb81cc0dd	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_094	integer	96	f
18daf0b0-1fe1-4ff2-8c82-e8aecb323474	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_095	integer	97	f
ef451871-25bb-4bc0-add6-239b3b143ead	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_096	integer	98	f
1edec3ba-6c4f-4fc0-a12d-460326f194d6	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_097	integer	99	f
a2d1ad93-99e4-4c89-af81-5ae9f42e9a47	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_098	integer	100	f
8e765df2-5de7-4b8e-baec-d09ab397988d	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_099	integer	101	f
ba1764a4-f3d5-4e53-9f60-c842b70bebdf	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_100	integer	102	f
cb985908-0ed9-464a-886f-e30d70581bec	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_101	integer	103	f
1b0f2411-9ec3-4fc1-9415-34aac7af9ba9	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_102	character varying	104	f
4d14ed9f-973e-4cad-b665-ad4eb6f6ada7	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_103	character varying	105	f
953adf66-e222-4aca-bde8-a6a32c89488c	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_104	character varying	106	f
55e50485-d40b-453e-861d-6f151cdd104a	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_105	character varying	107	f
e58c37c6-b693-40d4-bf03-d3d87119a45e	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_106	character varying	108	f
6fc9db87-f790-4370-bb8d-c4b2be95e760	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_107	character varying	109	f
3923520a-4753-4b9e-bcf7-5d34d0bfea1b	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_108	character varying	110	f
0508c6a7-c9bf-4fb7-a7a7-6643c332d5b7	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_109	character varying	111	f
5cf47b3e-2de3-4419-9332-db13ba8780b5	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_110	character varying	112	f
2ad97ff7-4395-4496-9efd-5a57620c20da	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_111	character varying	113	f
652418d7-2994-45f4-8b54-1dbf0df3155b	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_112	character varying	114	f
2096c5e9-fdfb-484f-b709-294dc16eb820	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_113	character varying	115	f
4fe532b7-3d52-4071-9c62-89f650881e60	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_114	character varying	116	f
404f77f4-d2e2-493f-b5e9-3c3771a34522	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_115	character varying	117	f
35df2fe8-3f01-4d34-a1ae-15a3aba377a7	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_116	character varying	118	f
0515d497-039f-4006-8ac2-0b3b092689c9	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_117	character varying	119	f
2764d0d2-3c58-4e2d-a548-af24455fbcac	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_118	character varying	120	f
c341d1fb-95a4-414a-901b-7e71185d4e53	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_119	character varying	121	f
fbff997e-a4ff-48be-9277-bb70676b8660	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_120	character varying	122	f
a60951aa-fb70-4b5e-a875-c9d95d8b2a74	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_121	character varying	123	f
99d7e44e-c31b-4135-a3af-b4040f679726	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_122	character varying	124	f
9923e13e-3c0b-486e-a7bc-786fcf45fae3	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_123	character varying	125	f
7120f663-0d2b-4723-a111-8283b0756ae3	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_124	character varying	126	f
dc4cfb70-5a67-44bd-a090-5d1ded7145bd	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_125	character varying	127	f
a1b40fba-b483-4658-b238-6d0bf14e8abf	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_126	character varying	128	f
a39d5350-c8ea-4c40-b4ef-e600f9060c6e	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_127	character varying	129	f
700f7b26-a01c-4e09-8118-9871f8902d51	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_128	character varying	130	f
d2c3dbc0-17ff-4276-a803-61465cb56949	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_129	character varying	131	f
af762ca2-ef3c-4d56-b057-9bdd79e75f59	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_130	character varying	132	f
b59eea68-4bef-4c16-94a6-855cd19d1777	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_131	character varying	133	f
7a3101da-1ff8-4b7a-a602-fddd0474e20c	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_132	character varying	134	f
a5d05145-657e-42b6-ae64-686fd520dca5	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_133	character varying	135	f
d36352ea-b43c-4595-812b-7bd45133247c	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_134	character varying	136	f
89271941-6528-42f5-a1f8-011845a7951e	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_135	character varying	137	f
6d8b5d29-a487-4354-8669-7cf32451f43c	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_136	character varying	138	f
a1851df6-5b75-4a40-b522-028951a7ff31	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_137	character varying	139	f
773e734b-fc4f-490b-9977-063b8d73d74f	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_138	character varying	140	f
b507e00f-a064-4336-9b87-88761310f045	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_139	character varying	141	f
98a76e62-995e-4e77-be33-15fdbecd8d10	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_140	character varying	142	f
0c76145b-7c53-42ae-938e-ac4544a87076	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	l01_141	character varying	143	f
04a72c6c-70f7-4ded-89b9-ff907520d29b	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	price_yen_m2	integer	1001	f
d82f5925-49e8-4fef-9e48-bdb60ef36cb4	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	tsubo_price_yen	integer	1002	f
c7e219e4-8e91-4939-8d89-6fa3c52194e9	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	municipality	text	1003	f
ebe9e598-6f3a-41c0-a85c-1a41b0afe24d	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	address	text	1004	f
09b2e446-a398-4cae-a0a3-5299f2c35bb9	54240d3d-0b3d-4d66-9f6d-07af52c6df5a	nearest_station	text	1005	f
a4517867-76bb-4c09-9b41-41680635058e	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	fid	integer	1	f
5b11a4b6-bf9e-477c-882c-91416f6268f9	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	geom	geometry	2	t
48457059-3f0e-4216-b3d7-807830ce366e	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	key_code	character varying	3	f
2a197b6f-75d4-4e24-b173-83292c0afb17	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	pref	character varying	4	f
7f88b3eb-f1ed-4bcf-b695-3d69adb0ad3d	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	city	character varying	5	f
90bf4e6e-4184-4e70-9504-a68303bd83ac	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	s_area	character varying	6	f
08bd8d50-b356-41ff-a60e-9dc57836d1b2	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	pref_name	character varying	7	f
2618d0f4-5b60-40b1-b3e6-ced4567c4ae2	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	city_name	character varying	8	f
a5ce33c7-2823-4ceb-9ca4-325e6bb44b2d	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	s_name	character varying	9	f
3286aa75-d51b-41e8-a7c1-a7785dc154a6	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	kigo_e	character varying	10	f
57c00772-d7dd-4cd5-a41e-d88b45949f0d	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	hcode	integer	11	f
92c18ecd-5c5d-4ef8-b723-7f322dc4bead	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	area	double precision	12	f
3d10a59b-4359-46b5-857f-77e989e80415	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	perimeter	double precision	13	f
8fbe168c-d4f8-45ae-8ad6-fc0a9ae8eb5c	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	r2kaxx	integer	14	f
d2dd5b9e-e529-4e7c-b8bf-bfeb2a384f2a	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	r2kaxx_id	integer	15	f
a7cea8d7-6e2d-4be9-91c6-2465c87cca1a	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	kihon1	character varying	16	f
1b89dd37-ae78-4f44-9364-f55c1d8e81aa	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	dummy1	character varying	17	f
6cd3e781-e15d-406a-9bc1-428886495145	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	kihon2	character varying	18	f
a8c546ca-3130-41fb-b0c2-9766286ed90a	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	keycode1	character varying	19	f
fdc63133-f4d3-4ace-a6af-f3bea5b13116	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	keycode2	character varying	20	f
0f27c5fe-7c95-410f-a374-3e1254a756aa	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	area_max_f	character varying	21	f
d793838b-1d44-4c62-a69b-aac22b36c730	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	kigo_d	character varying	22	f
e880a48e-5c92-4d5b-a398-db03b0501eb4	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	n_ken	character varying	23	f
0b921d6b-2e45-464e-94d6-dd95d7f43c25	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	n_city	character varying	24	f
3490cde3-d83b-41fa-81ae-4bf0692d2bab	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	kigo_i	character varying	25	f
12ae4672-b621-44c6-a83a-ff6bd4e245a5	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	kbsum	integer	26	f
46879bd5-0ca5-43ad-bcdc-2a28b172e650	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	jinko	bigint	27	f
3ea7609f-6079-4220-9eea-4fe3d8e0d630	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	setai	bigint	28	f
dd0c1f18-bbc8-4b2e-81e3-b0315d5c8ecc	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	x_code	double precision	29	f
12451c2c-6bf9-4dfd-a461-2fa65e194f59	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	y_code	double precision	30	f
4ebdaf1f-b5a9-46be-a071-9e7ef4723f86	5e7374f2-af82-481d-bc75-3e4ad51bfdaa	kcode1	character varying	31	f
\.
